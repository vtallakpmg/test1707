from checkov.argo_workflows.checks.template import *  # noqa
